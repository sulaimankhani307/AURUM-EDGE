# AURUM EDGE SK SCALPER (MetaTrader 5)

A free MetaTrader 5 custom indicator that marks potential BUY and SELL setups using EMA trend alignment, RSI, MACD, and ATR-based reference levels.

> **Important:** This is a technical-analysis tool, not an automated trading system. It does not place, modify, or close trades. Signals are not guarantees of future performance. Test on a demo account before considering live use.

## Features

- BUY and SELL arrows on the main chart.
- EMA 9 / 21 / 50 trend alignment (all periods configurable).
- RSI momentum confirmation.
- MACD main-line / signal-line confirmation.
- Configurable minimum confirmation score (1–5).
- ATR-based stop-loss and take-profit *reference levels* shown in the dashboard.
- Optional popup, sound, and push alerts.
- Closed-candle signal calculation: the forming candle (bar 0) is ignored.
- Configurable calculation-history limit.
- No external libraries or paid dependencies.

## Requirements

- MetaTrader 5 desktop terminal.
- MetaEditor included with MT5.
- A broker-provided symbol and price history. Gold symbols may be named `XAUUSD`, `GOLD`, or broker-specific variants.

## Installation

1. Download `AURUM_EDGE_SK_SCALPER.mq5` from this repository.
2. Open MetaTrader 5 and press **F4** to open MetaEditor.
3. In MetaEditor, choose **File → Open Data Folder** (or use the terminal's data-folder command).
4. Open `MQL5/Indicators/` and copy the `.mq5` file there.
5. Open the file in MetaEditor and press **F7** to compile.
6. Return to MT5. In **Navigator → Indicators**, right-click and choose **Refresh**.
7. Drag **AURUM EDGE SK SCALPER** onto a chart.

## Suggested starting settings

These are starting values for testing, not optimized or guaranteed settings.

| Parameter | Default |
|---|---:|
| Fast / Mid / Slow EMA | 9 / 21 / 50 |
| RSI period | 14 |
| BUY RSI threshold | 55 |
| SELL RSI threshold | 45 |
| MACD | 12 / 26 / 9 |
| Minimum confirmations | 4 of 5 |
| ATR period | 14 |
| ATR stop multiplier | 1.5 |
| Risk/reward reference | 2.0 |

M5 and M15 can be used as initial research timeframes for Gold, but suitability depends on broker feed, spread, execution, volatility, and the user's testing.

## How signals are calculated

The indicator checks five directional confirmations:

1. EMA trend: fast EMA above middle EMA above slow EMA for bullish conditions; inverse for bearish conditions.
2. Price location: close above/below fast EMA.
3. RSI above the BUY threshold or below the SELL threshold.
4. MACD main line above/below its signal line.
5. Candle direction: bullish/bearish candle body.

An arrow is drawn only when the corresponding EMA trend structure is aligned and the selected minimum confirmation count is reached. Only completed candles are evaluated; the current forming candle is not used for a signal.

## ATR reference levels

For the latest closed-candle signal, the dashboard calculates indicative levels from that candle's close:

- BUY: reference SL = close − ATR × stop multiplier; reference TP = close + (close − SL) × risk/reward.
- SELL: reference SL = close + ATR × stop multiplier; reference TP = close − (SL − close) × risk/reward.

These are chart references only. They are not broker orders and do not account for spread, commission, slippage, gaps, or execution constraints.

## Alerts

- Popup alerts are enabled by default.
- Sound alerts are optional and use a sound file in the MT5 terminal's `Sounds` folder.
- Push alerts are optional and require MetaQuotes ID / Notifications to be configured in MT5 terminal settings.

Alerts are checked when a new candle opens and refer to the candle that has just closed. On initial indicator attachment, the most recent historical signal is not sent as a new alert.

## Known limitations

- No economic-calendar/news filter.
- No VWAP, ADX, multi-timeframe filter, market-structure/BOS/CHoCH, liquidity-sweep, or fair-value-gap logic in this release.
- No automatic position sizing, trade execution, or account-risk calculation.
- Results can vary across brokers, symbol specifications, timeframes, and data feeds.
- This source has not been compiled or forward-tested by the repository maintainer in the user's MetaEditor environment. Compile locally and review any compiler output before use.

## Version history

### 1.10

- Improved input validation and parameter grouping.
- Added configurable confirmation score.
- Added optional sound and push notifications.
- Added calculation-history limit and clearer dashboard output.
- Kept signal evaluation on completed candles only.

### 1.00

- Initial EMA, RSI, MACD, ATR signal implementation.

## Disclaimer

For educational and informational purposes only. This software does not provide financial, investment, or trading advice. Trading leveraged products involves substantial risk and may not be suitable for every trader. Past performance does not guarantee future results. The user is responsible for independent testing and all trading decisions.

## License

See [LICENSE](LICENSE). If you distribute this project, retain the copyright and license notice.
