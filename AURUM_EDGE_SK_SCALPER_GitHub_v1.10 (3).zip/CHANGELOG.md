# Changelog

## [1.10] - 2026-11-22
- Added grouped and validated user inputs.
- Added configurable minimum confirmation score (1–5).
- Added optional sound and push alerts.
- Added a configurable maximum calculation-history range.
- Improved dashboard and code organization.
- Signals remain based on completed candles.

## [1.00]
- Initial EMA, RSI, MACD and ATR signal implementation.
