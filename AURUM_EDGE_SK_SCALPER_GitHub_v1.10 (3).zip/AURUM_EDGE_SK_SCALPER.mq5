//+------------------------------------------------------------------+
//|                 AURUM EDGE SK SCALPER                            |
//|                 MetaTrader 5 Custom Indicator                    |
//|                 Version 1.10                                     |
//+------------------------------------------------------------------+
#property copyright "AURUM EDGE SK SCALPER"
#property link      "https://github.com/"
#property version   "1.10"
#property description "Multi-confirmation trend and momentum signals for MetaTrader 5."
#property description "Uses EMA alignment, RSI, MACD and ATR-based reference levels."
#property indicator_chart_window
#property indicator_buffers 2
#property indicator_plots   2

#property indicator_label1  "AURUM BUY"
#property indicator_type1   DRAW_ARROW
#property indicator_color1  clrLimeGreen
#property indicator_width1  2

#property indicator_label2  "AURUM SELL"
#property indicator_type2   DRAW_ARROW
#property indicator_color2  clrTomato
#property indicator_width2  2

//--- Trend settings
input group "Trend Confirmation"
input int      InpFastEMA             = 9;       // Fast EMA period
input int      InpMidEMA              = 21;      // Middle EMA period
input int      InpSlowEMA             = 50;      // Slow EMA period

//--- Momentum settings
input group "Momentum Confirmation"
input int      InpRSIPeriod           = 14;      // RSI period
input double   InpRSIBuyLevel         = 55.0;    // Minimum RSI for BUY
input double   InpRSISellLevel        = 45.0;    // Maximum RSI for SELL
input int      InpMACDFast            = 12;      // MACD fast EMA
input int      InpMACDSlow            = 26;      // MACD slow EMA
input int      InpMACDSignal          = 9;       // MACD signal period
input int      InpMinConfirmations    = 4;       // Required confirmations (1-5)

//--- Risk reference settings
input group "ATR Risk Reference (Not Trading Orders)"
input int      InpATRPeriod           = 14;      // ATR period
input double   InpATRStopMultiplier   = 1.5;     // Stop distance = ATR x multiplier
input double   InpRiskReward          = 2.0;     // Target distance / stop distance

//--- Display and alert settings
input group "Display and Alerts"
input bool     InpShowDashboard       = true;    // Show chart dashboard
input bool     InpEnablePopupAlerts   = true;    // Popup alerts
input bool     InpEnablePushAlerts    = false;   // Push notifications (terminal must be configured)
input bool     InpEnableSound         = false;   // Play alert sound
input string   InpSoundFile           = "alert.wav"; // Sound file in terminal Sounds folder
input int      InpArrowOffsetPoints   = 20;      // Arrow distance from candle (points)
input int      InpMaxBarsToCalculate  = 3000;    // Calculation history limit

//--- Indicator buffers
double BuyBuffer[];
double SellBuffer[];

//--- Indicator handles
int g_fastEmaHandle = INVALID_HANDLE;
int g_midEmaHandle  = INVALID_HANDLE;
int g_slowEmaHandle = INVALID_HANDLE;
int g_rsiHandle     = INVALID_HANDLE;
int g_macdHandle    = INVALID_HANDLE;
int g_atrHandle     = INVALID_HANDLE;

datetime g_lastAlertBarTime = 0;

//+------------------------------------------------------------------+
//| Release indicator handles                                        |
//+------------------------------------------------------------------+
void ReleaseIndicatorHandles()
{
   if(g_fastEmaHandle != INVALID_HANDLE)
   {
      IndicatorRelease(g_fastEmaHandle);
      g_fastEmaHandle = INVALID_HANDLE;
   }
   if(g_midEmaHandle != INVALID_HANDLE)
   {
      IndicatorRelease(g_midEmaHandle);
      g_midEmaHandle = INVALID_HANDLE;
   }
   if(g_slowEmaHandle != INVALID_HANDLE)
   {
      IndicatorRelease(g_slowEmaHandle);
      g_slowEmaHandle = INVALID_HANDLE;
   }
   if(g_rsiHandle != INVALID_HANDLE)
   {
      IndicatorRelease(g_rsiHandle);
      g_rsiHandle = INVALID_HANDLE;
   }
   if(g_macdHandle != INVALID_HANDLE)
   {
      IndicatorRelease(g_macdHandle);
      g_macdHandle = INVALID_HANDLE;
   }
   if(g_atrHandle != INVALID_HANDLE)
   {
      IndicatorRelease(g_atrHandle);
      g_atrHandle = INVALID_HANDLE;
   }
}

//+------------------------------------------------------------------+
//| Initialization                                                   |
//+------------------------------------------------------------------+
int OnInit()
{
   //--- Validate user inputs
   if(InpFastEMA <= 0 || InpMidEMA <= 0 || InpSlowEMA <= 0 ||
      InpFastEMA >= InpMidEMA || InpMidEMA >= InpSlowEMA ||
      InpRSIPeriod <= 0 || InpATRPeriod <= 0 ||
      InpMACDFast <= 0 || InpMACDSlow <= InpMACDFast || InpMACDSignal <= 0 ||
      InpRSISellLevel < 0.0 || InpRSIBuyLevel > 100.0 ||
      InpRSISellLevel >= InpRSIBuyLevel ||
      InpMinConfirmations < 1 || InpMinConfirmations > 5 ||
      InpATRStopMultiplier <= 0.0 || InpRiskReward <= 0.0 ||
      InpArrowOffsetPoints < 0 || InpMaxBarsToCalculate < 100)
   {
      Print("AURUM EDGE SK SCALPER: Invalid input parameters. Check the Inputs tab.");
      return INIT_PARAMETERS_INCORRECT;
   }

   //--- Bind output buffers
   if(!SetIndexBuffer(0, BuyBuffer, INDICATOR_DATA) ||
      !SetIndexBuffer(1, SellBuffer, INDICATOR_DATA))
   {
      Print("AURUM EDGE SK SCALPER: Failed to bind indicator buffers.");
      return INIT_FAILED;
   }

   ArraySetAsSeries(BuyBuffer, true);
   ArraySetAsSeries(SellBuffer, true);

   PlotIndexSetInteger(0, PLOT_ARROW, 233);
   PlotIndexSetInteger(1, PLOT_ARROW, 234);
   PlotIndexSetDouble(0, PLOT_EMPTY_VALUE, EMPTY_VALUE);
   PlotIndexSetDouble(1, PLOT_EMPTY_VALUE, EMPTY_VALUE);
   PlotIndexSetInteger(0, PLOT_DRAW_BEGIN, InpSlowEMA);
   PlotIndexSetInteger(1, PLOT_DRAW_BEGIN, InpSlowEMA);

   IndicatorSetString(INDICATOR_SHORTNAME, "AURUM EDGE SK SCALPER v1.10");
   IndicatorSetInteger(INDICATOR_DIGITS, _Digits);

   //--- Create built-in indicator handles
   g_fastEmaHandle = iMA(_Symbol, _Period, InpFastEMA, 0, MODE_EMA, PRICE_CLOSE);
   g_midEmaHandle  = iMA(_Symbol, _Period, InpMidEMA, 0, MODE_EMA, PRICE_CLOSE);
   g_slowEmaHandle = iMA(_Symbol, _Period, InpSlowEMA, 0, MODE_EMA, PRICE_CLOSE);
   g_rsiHandle     = iRSI(_Symbol, _Period, InpRSIPeriod, PRICE_CLOSE);
   g_macdHandle    = iMACD(_Symbol, _Period, InpMACDFast, InpMACDSlow,
                           InpMACDSignal, PRICE_CLOSE);
   g_atrHandle     = iATR(_Symbol, _Period, InpATRPeriod);

   if(g_fastEmaHandle == INVALID_HANDLE ||
      g_midEmaHandle  == INVALID_HANDLE ||
      g_slowEmaHandle == INVALID_HANDLE ||
      g_rsiHandle     == INVALID_HANDLE ||
      g_macdHandle    == INVALID_HANDLE ||
      g_atrHandle     == INVALID_HANDLE)
   {
      Print("AURUM EDGE SK SCALPER: Could not create one or more indicator handles. Error: ",
            GetLastError());
      ReleaseIndicatorHandles();
      return INIT_FAILED;
   }

   return INIT_SUCCEEDED;
}

//+------------------------------------------------------------------+
//| Main calculation                                                 |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
{
   const int minimumBars = MathMax(InpSlowEMA,
                           MathMax(InpRSIPeriod,
                           MathMax(InpATRPeriod, InpMACDSlow + InpMACDSignal))) + 5;
   if(rates_total < minimumBars)
      return 0;

   //--- Use series indexing: index 0 is the forming candle, index 1 is closed.
   ArraySetAsSeries(time, true);
   ArraySetAsSeries(open, true);
   ArraySetAsSeries(high, true);
   ArraySetAsSeries(low, true);
   ArraySetAsSeries(close, true);

   const int barsToCopy = MathMin(rates_total, InpMaxBarsToCalculate);

   double fastEma[], midEma[], slowEma[];
   double rsi[], macdMain[], macdSignal[], atr[];

   ArraySetAsSeries(fastEma, true);
   ArraySetAsSeries(midEma, true);
   ArraySetAsSeries(slowEma, true);
   ArraySetAsSeries(rsi, true);
   ArraySetAsSeries(macdMain, true);
   ArraySetAsSeries(macdSignal, true);
   ArraySetAsSeries(atr, true);

   //--- Copy indicator data; do not calculate from incomplete data.
   if(CopyBuffer(g_fastEmaHandle, 0, 0, barsToCopy, fastEma) < barsToCopy) return prev_calculated;
   if(CopyBuffer(g_midEmaHandle,  0, 0, barsToCopy, midEma)  < barsToCopy) return prev_calculated;
   if(CopyBuffer(g_slowEmaHandle, 0, 0, barsToCopy, slowEma) < barsToCopy) return prev_calculated;
   if(CopyBuffer(g_rsiHandle,     0, 0, barsToCopy, rsi)     < barsToCopy) return prev_calculated;
   if(CopyBuffer(g_macdHandle,    0, 0, barsToCopy, macdMain) < barsToCopy) return prev_calculated;
   if(CopyBuffer(g_macdHandle,    1, 0, barsToCopy, macdSignal) < barsToCopy) return prev_calculated;
   if(CopyBuffer(g_atrHandle,     0, 0, barsToCopy, atr)     < barsToCopy) return prev_calculated;

   //--- Reset only the history range managed by this indicator.
   for(int i = 0; i < barsToCopy; i++)
   {
      BuyBuffer[i]  = EMPTY_VALUE;
      SellBuffer[i] = EMPTY_VALUE;
   }

   //--- Evaluate completed candles only. Candle 0 is intentionally ignored.
   for(int i = barsToCopy - 2; i >= 1; i--)
   {
      if(atr[i] <= 0.0 || rsi[i] == EMPTY_VALUE)
         continue;

      const bool bullishTrend = (fastEma[i] > midEma[i] && midEma[i] > slowEma[i]);
      const bool bearishTrend = (fastEma[i] < midEma[i] && midEma[i] < slowEma[i]);

      const bool bullishPrice = (close[i] > fastEma[i]);
      const bool bearishPrice = (close[i] < fastEma[i]);

      const bool bullishRSI = (rsi[i] >= InpRSIBuyLevel);
      const bool bearishRSI = (rsi[i] <= InpRSISellLevel);

      const bool bullishMACD = (macdMain[i] > macdSignal[i]);
      const bool bearishMACD = (macdMain[i] < macdSignal[i]);

      const bool bullishCandle = (close[i] > open[i]);
      const bool bearishCandle = (close[i] < open[i]);

      int buyConfirmations = 0;
      int sellConfirmations = 0;

      if(bullishTrend)  buyConfirmations++;
      if(bullishPrice)  buyConfirmations++;
      if(bullishRSI)    buyConfirmations++;
      if(bullishMACD)   buyConfirmations++;
      if(bullishCandle) buyConfirmations++;

      if(bearishTrend)  sellConfirmations++;
      if(bearishPrice) sellConfirmations++;
      if(bearishRSI)   sellConfirmations++;
      if(bearishMACD)  sellConfirmations++;
      if(bearishCandle) sellConfirmations++;

      //--- Require the EMA trend structure plus the selected confirmation score.
      if(bullishTrend && buyConfirmations >= InpMinConfirmations)
         BuyBuffer[i] = low[i] - (InpArrowOffsetPoints * _Point);
      else if(bearishTrend && sellConfirmations >= InpMinConfirmations)
         SellBuffer[i] = high[i] + (InpArrowOffsetPoints * _Point);
   }

   //--- Dashboard uses the most recently closed candle's signal.
   if(InpShowDashboard)
   {
      string signalText = "WAITING";
      string stopText   = "--";
      string targetText = "--";
      string signalTime = "--";

      if(BuyBuffer[1] != EMPTY_VALUE)
      {
         const double entry = close[1];
         const double stop  = entry - (atr[1] * InpATRStopMultiplier);
         const double target = entry + ((entry - stop) * InpRiskReward);
         signalText = "BUY";
         stopText = DoubleToString(stop, _Digits);
         targetText = DoubleToString(target, _Digits);
         signalTime = TimeToString(time[1], TIME_DATE | TIME_MINUTES);
      }
      else if(SellBuffer[1] != EMPTY_VALUE)
      {
         const double entry = close[1];
         const double stop  = entry + (atr[1] * InpATRStopMultiplier);
         const double target = entry - ((stop - entry) * InpRiskReward);
         signalText = "SELL";
         stopText = DoubleToString(stop, _Digits);
         targetText = DoubleToString(target, _Digits);
         signalTime = TimeToString(time[1], TIME_DATE | TIME_MINUTES);
      }

      string dashboard =
         "AURUM EDGE SK SCALPER v1.10\n" +
         "Symbol: " + _Symbol + " | Timeframe: " + EnumToString(_Period) + "\n" +
         "Last closed bar signal: " + signalText + "\n" +
         "RSI: " + DoubleToString(rsi[1], 2) +
         " | ATR: " + DoubleToString(atr[1], _Digits) + "\n" +
         "Reference SL: " + stopText + "\n" +
         "Reference TP: " + targetText + "\n" +
         "Signal bar: " + signalTime + "\n" +
         "Signals use closed candles only";
      Comment(dashboard);
   }
   else
   {
      Comment("");
   }

   //--- Alert once per newly opened candle for the just-closed candle.
   if(g_lastAlertBarTime == 0)
   {
      g_lastAlertBarTime = time[0];
   }
   else if(time[0] != g_lastAlertBarTime)
   {
      g_lastAlertBarTime = time[0];
      string alertMessage = "";

      if(BuyBuffer[1] != EMPTY_VALUE)
         alertMessage = "AURUM EDGE SK SCALPER: BUY | " + _Symbol + " | " + EnumToString(_Period);
      else if(SellBuffer[1] != EMPTY_VALUE)
         alertMessage = "AURUM EDGE SK SCALPER: SELL | " + _Symbol + " | " + EnumToString(_Period);

      if(alertMessage != "")
      {
         if(InpEnablePopupAlerts)
            Alert(alertMessage);
         if(InpEnablePushAlerts)
         {
            if(!SendNotification(alertMessage))
               Print("AURUM EDGE SK SCALPER: Push notification failed. Check MT5 notification settings. Error: ", GetLastError());
         }
         if(InpEnableSound)
            PlaySound(InpSoundFile);
      }
   }

   return rates_total;
}

//+------------------------------------------------------------------+
//| Deinitialization                                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   ReleaseIndicatorHandles();
   Comment("");
}
//+------------------------------------------------------------------+
